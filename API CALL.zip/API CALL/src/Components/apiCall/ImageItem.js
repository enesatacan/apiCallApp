function ImageItem({ image }) {
  console.log(image);
  return (
    <div>
      <img
        style={{
          borderRadius: "36px",
          boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
        }}
        src={image.urls.small}
        alt={image.alt_description}
      />
    </div>
  );
}

export default ImageItem;
