import React from "react";
import {
  FormControl,
  InputLabel,
  Input,
  FormHelperText,
  Grid,
} from "@mui/material";
import { useState } from "react";

function Form({ search }) {
  const [value, setValue] = useState("");
  const handleChange = (event) => {
    setValue(event.target.value);
  };
  const handleFormSubmit = (event) => {
    event.preventDefault();
    search(value);
  };
  return (
    <>
      <Grid container justifyContent={"center"} my={5}>
        <form onSubmit={handleFormSubmit}>
          <FormControl>
            <InputLabel>Search</InputLabel>
            <Input value={value} onChange={handleChange} />
            <FormHelperText>
              Type the word you want to search for and click enter...
            </FormHelperText>
          </FormControl>
        </form>
      </Grid>
    </>
  );
}

export default Form;
