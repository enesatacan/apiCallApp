import ImageItem from "./ImageItem";

function ImageList({ imagesPlaceholder }) {
  return (
    <div
      style={{
        display: "flex",
        borderRadius: "36px",
        gap: 5,
        flexWrap: "wrap",
        justifyContent: "center",
      }}
    >
      {imagesPlaceholder.map((image, index) => {
        return <ImageItem key={index} image={image} />;
      })}
    </div>
  );
}

export default ImageList;
