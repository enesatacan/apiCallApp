import React from "react";
import Form from "./Form";
import searchImages from "./Api";
import { useState } from "react";
import ImageList from "./ImageList";
import { Grid } from "@mui/material";

function Main() {
  const [images, setImages] = useState([]);
  const handleSubmit = async (term) => {
    const result = await searchImages(term);
    setImages(result);
  };
  return (
    <>
      <Grid xs container sx={{ justifyContent: "center" }}>
        <Grid item xs={10} lg={6}>
          <p className="paragraph">
            In this project, the user receives the image he wants to be listed
            through a form via an input.
            <br />
            <br />
            In this way, the value received from the user is sent to
            unsplash.com via axios. If the response is successful, 10 images are
            printed on the screen.
          </p>
        </Grid>
      </Grid>
      <Form search={handleSubmit} />
      <ImageList imagesPlaceholder={images} />
    </>
  );
}

export default Main;
